
const photo={
 burger:'images/burger-01.jpg',
 shawarma:'images/shawarma-01.jpg',
 black:'images/black-01.jpg',
 wings:'images/wings-01.jpg',
 nuggets:'images/nuggets-01.jpg',
 fries:'images/fries-01.jpg',
 pizza:'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=700&q=80',
 drink:'images/drink-01.jpg',
 coke:'images/coke-01.jpg',
 fanta:'images/fanta-01.jpg',
 sprite:'images/sprite-01.jpg',
 fuse:'images/fuse-01.jpg',
 piko:'images/piko-01.jpg',
 bonaqua:'images/bonaqua-01.jpg',
 nitro:'images/nitro-01.jpg',
 gorilla:'images/gorilla-01.jpg',
 tea:'images/tea-01.jpg',
 greentea:'images/greentea-01.jpg',
 dada:'images/dada-01.jpg',
 chalap:'images/chalap-01.jpg',
 compote:'images/compote-01.jpg',
 sauce:'images/sauce-01.jpg',
 cheese:'images/cheese-01.jpg', garlic:'images/garlic-01.jpg', ketchup:'images/ketchup-01.jpg', jalapeno:'images/jalapeno-01.jpg',
 sprite:'images/sprite-02.jpg', chalap:'images/chalap-02.jpg', fuse:'images/fuse-02.jpg', dada:'images/dada-02.jpg', bonaqua:'images/bonaqua-02.jpg', nitro:'images/nitro-02.jpg',
 macaron_coconut:'images/macaron_coconut-01.jpg', macaron_pistachio:'images/macaron_pistachio-01.jpg', macaron_mango:'images/macaron_mango-01.jpg',
 macaron:'https://images.unsplash.com/photo-1569864358642-9d1684040f43?auto=format&fit=crop&w=700&q=80'
};
const menu=[
['Бургеры','Бургер',199,'burger'],['Бургеры','Двойной бургер',259,'burger'],['Бургеры','Чизбургер',219,'burger'],['Бургеры','Двойной чизбургер',279,'burger'],['Бургеры','Чикен бургер',219,'burger'],
['Шаурма','Классика',229,'shawarma'],['Шаурма','Классика запеченная',249,'shawarma'],['Шаурма','Мини шаурма',199,'shawarma'],['Шаурма','Мини запеченная',219,'shawarma'],['Шаурма','Куриная шаурма',220,'shawarma'],['Шаурма','Куриная запеченная',239,'shawarma'],['Шаурма','Сырная',239,'shawarma'],['Шаурма','Сырная запеченная',259,'shawarma'],['Шаурма','Курица двойной',269,'shawarma'],['Шаурма','Курица запечённый двойной',289,'shawarma'],
['Black King','Black King',249,'black'],['Black King','Black King Двойной',299,'black'],
['Острые крылышки','6 шт.',249,'wings'],['Острые крылышки','12 шт.',489,'wings'],['Острые крылышки','18 шт.',729,'wings'],['Острые крылышки','24 шт.',979,'wings'],
['Наггетсы','5 шт.',129,'nuggets'],['Наггетсы','8 шт.',179,'nuggets'],['Наггетсы','12 шт.',239,'nuggets'],
['Картофель фри','200 г',149,'fries'],
['Соусы','Сырный соус',30,'sauce'],['Соусы','Чесночный соус',30,'sauce'],['Соусы','Кетчуп',30,'sauce'],['Соусы','Халапеньо',30,'sauce'],
['Пицца','Пепперони 30 см',450,'pizza'],['Пицца','Пепперони 35 см',560,'pizza'],['Пицца','4 сезона 30 см',460,'pizza'],['Пицца','4 сезона 35 см',570,'pizza'],['Пицца','Пицца по-мексикански 30 см',480,'pizza'],['Пицца','Пицца по-мексикански 35 см',590,'pizza'],['Пицца','2 сезона 30 см',450,'pizza'],['Пицца','2 сезона 35 см',560,'pizza'],
['Напитки','Кока-Кола 0,5 л',75,'drink'],['Напитки','Кока-Кола 1 л',110,'drink'],['Напитки','Кока-Кола 1,5 л',140,'drink'],['Напитки','Кока-Кола 2 л',190,'drink'],['Напитки','Фанта 0,5 л',75,'drink'],['Напитки','Фанта 1 л',110,'drink'],['Напитки','Фанта 1,5 л',140,'drink'],['Напитки','Фанта 2 л',190,'drink'],['Напитки','Sprite 0,5 л',75,'drink'],['Напитки','Sprite 1 л',110,'drink'],['Напитки','Sprite 1,5 л',140,'drink'],['Напитки','Sprite 2 л',190,'drink'],['Напитки','Fuse Tea 0,5 л',75,'drink'],['Напитки','Fuse Tea 1 л',110,'drink'],['Напитки','Piko 0,5 л',80,'drink'],['Напитки','Piko 1 л',140,'drink'],['Напитки','Bonaqua 0,5 л',45,'drink'],['Напитки','Компот 1 л',100,'drink'],['Напитки','Нитро 450 мл',80,'drink'],['Напитки','Gorilla 450 мл',85,'drink'],['Напитки','Dada 200 мл',45,'drink'],['Напитки','Чалап 300 мл',60,'drink'],['Напитки','Чай чёрный 200 мл',25,'drink'],['Напитки','Чай зелёный 200 мл',25,'drink'],
['Макаронс','Фисташка малина',219,'macaron','Нежный фисташковый крем с яркой малиновой ноткой'],['Макаронс','Кокосовый',219,'macaron','Нежный кокосовый крем с тропическим ароматом'],['Макаронс','Манго Маракуйя',219,'macaron','Яркое сочетание сочного манго и экзотической маракуйи']
];
const categories=['Все','Бургеры','Шаурма','Black King','Острые крылышки','Наггетсы','Картофель фри','Соусы','Пицца','Напитки','Макаронс'];
let active='Все',cart={};
const chips=document.getElementById('chips');
categories.forEach(c=>{let b=document.createElement('button');b.className='chip'+(c==='Все'?' active':'');b.textContent=c;b.onclick=()=>{active=c;document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('active',x.textContent===c));renderMenu()};chips.appendChild(b)});
function drinkPhoto(name){
 const n=name.toLowerCase();
 if(n.includes('кока')) return photo.coke;
 if(n.includes('фанта')) return photo.fanta;
 if(n.includes('sprite')) return photo.sprite;
 if(n.includes('fuse')) return photo.fuse;
 if(n.includes('piko')) return photo.piko;
 if(n.includes('bonaqua')) return photo.bonaqua;
 if(n.includes('горилл')||n.includes('gorilla')) return photo.gorilla; if(n.includes('нитро')) return photo.nitro;
 if(n.includes('dada')) return photo.dada;
 if(n.includes('чалап')) return photo.chalap;
 if(n.includes('компот')) return photo.compote;
 if(n.includes('зелёный')||n.includes('зеленый')) return photo.greentea;
 if(n.includes('чай')) return photo.tea;
 return photo.drink;
}
function renderMenu(){
 const q=document.getElementById('search').value.toLowerCase();
 const items=menu.filter(x=>(active==='Все'||x[0]===active)&&(x[1]+' '+x[0]).toLowerCase().includes(q));
 const grid=document.getElementById('menuGrid');grid.innerHTML='';
 items.forEach((x,i)=>{let [cat,name,price,key,desc]=x;let card=document.createElement('article');card.className='card';let productPhoto=key==='drink'?drinkPhoto(name):(key==='macaron'?(name.toLowerCase().includes('фисташ')?photo.macaron_pistachio:name.toLowerCase().includes('кокос')?photo.macaron_coconut:photo.macaron_mango):(key==='sauce'?(name.includes('Сырный')?photo.cheese:name.includes('Чесночный')?photo.garlic:name.includes('Кетчуп')?photo.ketchup:photo.jalapeno):photo[key]));card.innerHTML=`<div class="card-img"><img class="${key==='drink'?'drink-image':''}" loading="lazy" src="${productPhoto}"  alt="${name}" onerror="this.parentElement.style.display='none'"></div><div class="card-body"><div style="color:#999;font-size:11px;text-transform:uppercase;letter-spacing:1px">${cat}</div><h3>${name}</h3><p>${desc|| (cat==='Острые крылышки'?'Соус бесплатно!':'')}</p><div class="card-foot"><div class="price">${price===null?'Цена уточняется':price+' сом'}</div>${price===null?'':`<button class="add" aria-label="Добавить ${name}" onclick="addItem('${name.replace(/'/g,"\\'")}',${price})">+</button>`}</div></div>`;grid.appendChild(card)});
 if(!items.length)grid.innerHTML='<p style="color:#aaa">Ничего не найдено. Попробуй другое название.</p>';
}
function addItem(name,price){cart[name]=(cart[name]||{price,qty:0});cart[name].qty++;updateCart();showToast('Добавлено: '+name)}
function updateCart(){let count=Object.values(cart).reduce((a,x)=>a+x.qty,0),total=Object.values(cart).reduce((a,x)=>a+x.price*x.qty,0);document.getElementById('cartCount').textContent=count;document.getElementById('cartTotal').textContent=total+' сом';let box=document.getElementById('cartItems');let entries=Object.entries(cart);box.innerHTML=entries.length?entries.map(([n,x])=>`<div class="cart-row"><span>${n} × ${x.qty}</span><b>${x.price*x.qty} сом</b></div>`).join(''):'<div class="empty">Пока ничего не добавлено.</div>'}
function toggleCart(){document.getElementById('cartPanel').classList.toggle('open')}
function clearCart(){cart={};updateCart()}
function copyOrder(){let entries=Object.entries(cart);if(!entries.length){showToast('Сначала добавь блюда');return}let total=entries.reduce((a,[n,x])=>a+x.price*x.qty,0);let txt='Здравствуйте! Хочу заказать в Daam Food:\\n'+entries.map(([n,x])=>`${n} × ${x.qty} — ${x.price*x.qty} сом`).join('\\n')+'\\nИтого: '+total+' сом';if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(()=>showToast('Заказ скопирован!')).catch(()=>showToast('Не удалось скопировать'))}else{showToast('Браузер не поддерживает копирование')}}
function sendOrder(){let entries=Object.entries(cart);if(!entries.length){showToast('Сначала добавь блюда');return}let name=document.getElementById('customerName').value.trim();let address=document.getElementById('customerAddress').value.trim();if(!name){document.getElementById('customerName').focus();showToast('Укажи своё имя');return}if(!address){document.getElementById('customerAddress').focus();showToast('Укажи адрес доставки');return}let total=entries.reduce((a,[n,x])=>a+x.price*x.qty,0);let txt='Здравствуйте! Хочу заказать в Daam Food:\nИмя: '+name+'\nАдрес доставки: '+address+'\n'+entries.map(([n,x])=>`${n} × ${x.qty} — ${x.price*x.qty} сом`).join('\n')+'\nИтого: '+total+' сом';window.open('https://wa.me/996550999352?text='+encodeURIComponent(txt),'_blank')}
function showToast(t){let el=document.getElementById('toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1700)}
renderMenu();updateCart();
